module.exports = (db, Sequelize) => {
    let UsersHistory = db.define(
      'usersLoginHistory',
      {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true,
        },
        createdAt: {
          type: Sequelize.DATE,
          defaultValue: Sequelize.NOW,
        },
        modifiedAt: {
          type: Sequelize.DATE,
          defaultValue: Sequelize.NOW,
        },
      },
      {
        tableName: 'usersLoginHistory',
        schema: 'users',
        underscored: true,
      }
    );
    UsersHistory.association = (models) => {
        UsersHistory.belongsTo(models.users, { foreignKey: 'user_id' });
    };
    
    return UsersHistory;
  };
  