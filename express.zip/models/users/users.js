module.exports = (db, Sequelize) => {
    let Users = db.define(
      'users',
      {
        id: {
          type: Sequelize.INTEGER,
          primaryKey: true,
          autoIncrement: true,
        },
        email: {
          type: Sequelize.STRING(100),
          allowNull: false,
          required: true,
        },
        password: {
          type: Sequelize.STRING,
          allowNull: true,
          required: true,
        },
        name: {
          type: Sequelize.STRING,
          allowNull: true,
          required: false,
        },
        createdAt: {
          type: Sequelize.DATE,
          defaultValue: Sequelize.NOW,
        },
        modifiedAt: {
          type: Sequelize.DATE,
          defaultValue: Sequelize.NOW,
        },
      },
      {
        tableName: 'users',
        schema: 'users',
        underscored: true,
      }
    );
    Users.association = (models) => {
      Users.hasMany(models.userLoginHistory, { foreignKey: 'user_id' });
    };
    
    return Users;
  };
  