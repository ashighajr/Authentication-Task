// const redis=require('redis');

// // const redis_client=redis.createClient(CONFIG.redis_port,CONFIG.redis_host);
// // redis_client.on('connect',function(){
// // console.log('redis client connected');
// // });

// module.exports=redis_client;