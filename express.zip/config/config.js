require('dotenv').config();//instatiate environment variables

CONFIG = {} //Make this global to use all over the application


CONFIG.app = process.env.APP || 'dev';
CONFIG.port = process.env.PORT || '3000';

CONFIG.db_dialect = process.env.DB_DIALECT || 'postgres';
CONFIG.db_host = process.env.DB_HOST || 'localhost';
CONFIG.db_port = process.env.DB_PORT || '5432';
CONFIG.db_name = process.env.DB_NAME || 'sample';
CONFIG.db_user = process.env.DB_USER || 'postgres';
CONFIG.db_password = process.env.DB_PASSWORD;
CONFIG.expires_in=Date.now();


/*Jwt Configuration*/
CONFIG.jwt_encryption = process.env.JWT_ENCRYPTION || 'Hello';
CONFIG.jwt_expiration = process.env.JWT_EXPIRATION || '86400000';
CONFIG.refresh_token_expiration = process.env.REFRESH_TOKEN_EXPIRATION || '3600000';

/*Server performance Configuration*/
CONFIG.max_device_limit = process.env.MAX_DEVICE_LIMIT || 10;
CONFIG.max_pool_conn = process.env.MAX_POOL_CONN || '100';
CONFIG.min_pool_conn = process.env.MIN_POOL_CONN || '0';
CONFIG.conn_idle_time = process.env.CONN_IDLE_TIME || '10000';

CONFIG.secret_key = "mysecretkey";
CONFIG.refreshToken_expiration=3600000;
CONFIG.redis_host=process.env.REDIS_HOST;
CONFIG.redis_port=process.env.REDIS_HOST_PORT;

