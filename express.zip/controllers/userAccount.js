
const User = require('../models').users;
const UserHistory=require('../models').userLoginHistory;
const jwt=require('jsonwebtoken');
// const redis_client=require('../routes/redis_account');
const randToken = require('rand-token');
let refreshTokens={};
//Add the new user to userAccount table
const login = async function (req, res) {
   let login,err,loginHistory;
   [err,login]=await to(User.findOne({
    attributes:['id','name','email','password'],   
    where:{
       email:req.body.email}
   }));
   if (err) {
    console.log('err', err.message);
    return ReE(res,
        Object.assign('Failure', { details: err.message }),
        422);
}
if(login){
if(login.password===req.body.password){
    console.log('login',login.dataValues.id);
     let refreshToken = randToken.uid(256);
      refreshTokens[refreshToken] = {
        expiredAt: Date.now() + CONFIG.refreshToken_expiration,
        user: login.dataValues
      };
      console.log('refesh token',refreshTokens[refreshToken]);
    //   redis_client.set(refreshTokens,JSON.stringify({token:refreshToken}));
    const token = getJWT(login.dataValues);
    [err,loginHistory]=await to(UserHistory.create({
        user_id:login.dataValues.id
    }))
    return ReS(res,{ accessToken: token,refreshToken: refreshToken, user: login.dataValues });
}
else{
    return ReE(res,
        Object.assign('Failure', { details: err.message }),
        422);  
}
}
return ReE(res,
    Object.assign('Failure', { details: err.message }),
    422);  

};

module.exports.login = login;

const register = async function (req, res) {
    let err,register;
    [err,register]=await to(User.create(req.body));
    if (err) {
        console.log('error while adding attachment', err.message);
        return ReE(res,
            Object.assign('Failure', { details: err.message }),
            422);
    }
    return ReS(res, 
        'success'
    , 200);

};

module.exports.register = register;
const userdetails = async function (req, res) {
    let err,userdetails,accesstoken;
    console.log('user id',req.query);
    [err,userdetails]=await to(User.findOne({
        where:{
            id:req.query.id
        }
    }));
    if(userdetails){
        // console.log('ghhhh',refreshTokens);
      accesstoken=getRefreshToken(req.query.refreshtoken); 
    }
    console.log('userdetails',accesstoken);
    if (err) {
        console.log('error while adding attachment', err.message);
        return ReE(res,
            Object.assign('Failure', { details: err.message }),
            422);
    }
    return ReS(res,{userdetails:userdetails,accessToken:accesstoken});

};

module.exports.userdetails = userdetails;
const logindetails = async function (req, res) {
    let err,loginhistory;
    [err,loginhistory]=await to(UserHistory.findAll({
        where:{
            user_id:req.query.id
        }
    }));
    if (err) {
        return ReE(res,
            Object.assign('Failure', { details: err.message }),
            422);
    }
    return ReS(res,{loginhistory:loginhistory});

};

module.exports.logindetails = logindetails;

const getJWT = function (user) {
      return "Bearer " + jwt.sign(user, CONFIG.jwt_encryption);
  
  };
  module.exports.getJWT = getJWT;


  const getRefreshToken = function (data) {
    const refreshToken = data;
    // console.log(' whole refresh token data = ',refreshToken,'ghggfhdghfg',refreshTokens);
    if (refreshToken in refreshTokens && refreshTokens[refreshToken] && refreshTokens[refreshToken].expiredAt > Date.now()) {
      // Get Access Token using getJWT().
      console.log('refresh token',refreshTokens[refreshToken].user);
      const token = getJWT(refreshTokens[refreshToken].user);
    //   console.log('accesstoken',token);
      return token;
    } else {
      return null;
    }
  };
  module.exports.getRefreshToken = getRefreshToken;