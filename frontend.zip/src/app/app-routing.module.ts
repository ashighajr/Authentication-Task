import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './user/components/home/home.component';

import { SigninComponent } from './user/components/signin/signin.component';
import { SignupComponent } from './user/components/signup/signup.component';


const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  
 { path: 'home', component: HomeComponent,children: [{

  path: 'signup', component: SignupComponent
  },{
    path:'signin',component:SigninComponent
  }]}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
