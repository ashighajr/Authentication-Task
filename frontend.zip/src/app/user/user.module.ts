import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignupComponent } from './components/signup/signup.component';
import { MaterialModule } from '../material/material.module';
import { UserRoutingModule } from './user-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { UserService } from './services/user.service';
import { SigninComponent } from './components/signin/signin.component';
import { HomeComponent } from './components/home/home.component';



@NgModule({
  declarations: [SignupComponent, SigninComponent,HomeComponent],
  imports: [
    CommonModule,
    UserRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,FlexLayoutModule
  ],
  providers: [UserService]
})
export class UserModule { }
