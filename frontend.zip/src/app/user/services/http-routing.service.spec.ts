import { TestBed } from '@angular/core/testing';

import { HttpRoutingService } from './http-routing.service';

describe('HttpRoutingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HttpRoutingService = TestBed.get(HttpRoutingService);
    expect(service).toBeTruthy();
  });
});
