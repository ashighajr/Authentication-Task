import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class HttpRoutingService {
  /**
   * Component constructor used to inject the required services.
   * @param httpClient To define the HttpClient.
   */
  constructor(private httpClient: HttpClient) { }

  /**
   * Method which is used to get the details from the server through the http request.
   * @param url Url route to get the data from the server.
   */
  getMethod(url: string, queryParam?) {
    return this.httpClient.get(environment.apiUrldb + 'v1/' + url, { params: queryParam });
  }
  /**
   * Method which is used to get and update the details in the server through the http request.
   * @param url Url route to get the data from the server.
   * @param data Data to be add or update in the server.
   */
  postMethod(url: string, data: any, queryParam?) {
    return this.httpClient.post(environment.apiUrldb + 'v1/' + url, data, { params: queryParam });
  }
}
