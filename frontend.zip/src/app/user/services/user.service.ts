import { Injectable } from '@angular/core';
import {  map } from 'rxjs/operators';
import { HttpRoutingService } from './http-routing.service';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpRoutingService: HttpRoutingService) { }

  register(data) {
    console.log('register', data);
    return this.httpRoutingService.postMethod('register', data);
  };
  signinUser(data){
    return this.httpRoutingService.postMethod('login', data);
  }
}
