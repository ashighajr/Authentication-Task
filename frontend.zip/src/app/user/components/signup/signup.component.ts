import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  signUpForm: FormGroup;
  subscriptionObj: Subscription = new Subscription();

  constructor( private userService: UserService, private snackBar: MatSnackBar,private router:Router) { }

  ngOnInit() {
    this.signUpForm = new FormGroup({
      email: new FormControl(null, [
        Validators.required,
        Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/)
        , ]),
      password: new FormControl(null, [
        Validators.required
      ]),
      name: new FormControl(null, [
        Validators.required
      ])


    });
  }
 submit(){

    this.subscriptionObj.add(this.userService.register({
      email: this.signUpForm.get('email').value,
      password: this.signUpForm.get('password').value,
      name:this.signUpForm.get('name').value
    }).subscribe((res) => {
      if (res) {
        console.log('success');
        console.log('response on token = ', res);
        this.snackBar.open('Register successful !', '', {
          duration: 2000,
          horizontalPosition: 'end',
          verticalPosition: 'bottom',
        });
        this.router.navigate(['/home']);
      }
    }, (err) => {
      console.log('error',err);
      this.snackBar.open('Invalid values !', '', {
        duration: 2000,
        horizontalPosition: 'end',
        verticalPosition: 'bottom',
      });
    }));
  }
 

}
