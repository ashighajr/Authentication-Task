import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {
  signInForm: FormGroup;
   subscriptionObj: Subscription = new Subscription();
  constructor(private _snackBar: MatSnackBar,private userService:UserService,private router:Router) { }

  ngOnInit() {
    this.signInForm = new FormGroup({
      email: new FormControl(null, [
        Validators.required,
        Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/)
        , ]),
      password: new FormControl(null, [
        Validators.required
      ]),
    });
  }
  onSignIn() {
    this.subscriptionObj.add(this.userService.signinUser({
      email: this.signInForm.get('email').value,
      password: this.signInForm.get('password').value
    }).subscribe((res) => {
      if (res) {
        console.log('success');
        console.log('response on token = ', res);
        this._snackBar.open('Login success !', '', {
          duration: 2000,
          horizontalPosition: 'end',
          verticalPosition: 'bottom',
        });
        this.router.navigate(['/home']);
      }
    }, (err) => {
      console.log('error',err);
      this._snackBar.open('Invalid Login Credentials !', '', {
        duration: 2000,
        horizontalPosition: 'end',
        verticalPosition: 'bottom',
      });
    }));
  }
}
