import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './material/material.module';
import { UserModule } from './user/user.module';
import { HttpRoutingService } from './user/services/http-routing.service';



@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    MaterialModule,
    AppRoutingModule,UserModule
  ],
  providers: [HttpRoutingService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
